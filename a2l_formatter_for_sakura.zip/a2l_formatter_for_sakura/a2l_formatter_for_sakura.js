//==================================================================================
//
// A2L formatter for Sakura editor (JScript版)
// 
//==================================================================================
// Copyright (c) 2021 toowaki
// Released under the MIT license
// https://opensource.org/licenses/mit-license.php
//==================================================================================
//------------------------------------------------------------------------------
// ユーザ設定
//------------------------------------------------------------------------------
//------------------------------------------
// インデントに関する設定
//------------------------------------------
var vParam_IndentStrForA2ML  = "  ";       // A2MLのインデント文字 (例：タブ1文字なら\t、スペース2文字なら"  ")
var vParam_IndentStrForOther = "    ";     // A2ML以外インデント文字 (例：タブ1文字なら\t、スペース4文字なら"    ")
var vParam_IndentForA2mlOn = true;         // true: A2MLに対するインデントとコメント調整を行う,  false: どちらも行わない

var vParam_TitleCommentIndentZero = false; // true: 行頭が/*から始まる行はインデントレベル0にて処理、
                                           // false:その他の行と同じインデント処理

//------------------------------------------
// コメントに関する設定
//------------------------------------------
var vParam_CommentFitOn = true;                   // 文末のコメント位置揃え(true:ON, false:OFF)
var vParam_CommentFit_EndSpaceOfBodyOn = true;    // 本体とコメントとの間を指定したスペース文字列に変換(true: ON, false: OFF)
var vParam_CommentFit_EndSpaceOfBodyStr = "    "; // 本体とコメントとの間のスペース文字列


//==============================================================================
//
//  MAIN
//
//==============================================================================
//------------------------------------------------------------------------------
//  初期化
//------------------------------------------------------------------------------
var vParam_Crlf = "\n";        // 改行文字
var vCntAll = GetLineCount(0); // 全体の行数
var vCntPos = -1;              // 継続行の開始位置
var vIndentLv = 0;             // インデントレベル
var vFormatLines = [];         // インデント調整後の内容が格納される配列
var vIsComment = false;        // コメント状態の場合、true
var vLineBody = "";            // インデント調整用 処理部
var vLineComm = "";            // インデント調整用 コメント部
var vA2mlLineOn = false;       // A2ML行の場合はtrue, A2ML行以外の記載はfalse

// デバッグ用
var shell = new ActiveXObject("WScript.Shell"); //「shell.Popup("Debug");」のように使用して変数を確認

//------------------------------------------------------------------------------
// インデント調整
//------------------------------------------------------------------------------
for (var i = 1; i <= vCntAll; i++) { //ファイルの1行目から最終行まで処理
    var vLine = GetLineStr(i).replace(/\r\n/,"").replace(/\n/,""); // 文末の改行削除

    // A2MLの確認
    var vBeginA2mlLine = false;
    if(vLine.match(/^\s*\/end\s+A2ML/)){
        vA2mlLineOn = false;    
    }
    else if((vLine.match(/^\s*\/begin\s+A2ML/))){
        vA2mlLineOn = true;
        vBeginA2mlLine = true;
    }
    else if(!vParam_IndentForA2mlOn && (vA2mlLineOn)){ // A2MLのインデントがOFF、かつ、現在のLineがA2MLの場合
        vFormatLines[vFormatLines.length] = vLine; 
        continue; // A2ML内であればインデントしない
    }

    //------------------------------------------
    // 本体とコメントに分ける
    //------------------------------------------
    vLine = vLine.replace(/\s+$/, "").replace(/^\s+/, ""); // 文頭と文末の空白を削除
    if(!vIsComment){ // コメント状態でない
        if (vLine.match(/\/[\/\*]/)) { // コメント開始文字「//」,「/*」を含む場合
            // コメントの位置を確認
            vIndexNum = f_CheckCommentIndex(vLine);// コメント位置を取得
            vLineBody = vLine.slice(0, vIndexNum); // 本体
            vLineComm = vLine.slice(vIndexNum, vLine.length); // コメント

            // もしコメント状態かつ、行に*/を含んでいる場合はコメント状態解除
            if(vLineComm.match(/\*\//))       vIsComment = false;
            else if(vLineComm.match(/^\/\//)) vIsComment = false;
            else                              vIsComment = true;
        }
        else{
            vIsComment = false;
            vLineBody = vLine;
            vLineComm = "";
        }
    }
    else{ //コメント状態。 上の行で/*があることを想定。
        if (vLine.match(/\*\//)) {// 「*/」を含む場合
            vIsComment = false;
            var vIndexNum = vLine.indexOf('*/');// 「*/」の位置を取得
            vLineComm = vLine.slice(0, vIndexNum+2); //コメント特殊文字2文字分加算してコメントと本体に分ける
            vLineBody = vLine.slice(vIndexNum+2, vLine.length);
        }
        else{
            vLineBody = "";
            vLineComm = vLine;
        }
        
        // /*-*/のコメント中であることをマークする
        if(vParam_CommentFitOn) vLineBody = "//___<COMMENT___MARK>___" + vLineBody; 
    }
    
    //------------------------------------------
    // インデントを揃える
    //------------------------------------------
    // 行頭が}、もしくは/endの時はインデントレベルをマイナス
    var vIndentAdjustLv = 0;
    if ((vLineBody.match(/^\}/)) ||
        (vLineBody.match(/^\/end\s/))){
        vIndentLv--;
        vIndentAdjustLv = 1;
    }

    // 行頭のインデントを揃える
    vLineBody = vLineBody.replace(/^(.*)$/, function(str, p1){
        var vText = "";
        if( (vParam_TitleCommentIndentZero == true) &&  // vParam_TitleCommentIndentZero= true時の処理
            (vLineBody == "") && (vLineComm.match(/^\s*\/\*/))){ // 本文は""でかつ、コメントは行頭が/*から始まる行はインデント0にて処理
                // 何もしない
        }
        else{ // 
            for (var j = 0; j < vIndentLv; j++) {
                if((!vBeginA2mlLine) && vA2mlLineOn){// A2ML
                    vText = vText + vParam_IndentStrForA2ML;
                }
                else{// A2ML以外の行
                    vText = vText + vParam_IndentStrForOther;
                }
            }
        }
        return vText + p1;
    });

    //------------------------------------------
    // 次行以降の処理に必要な情報の設定
    //------------------------------------------
    // [A2ML内] 末尾が"{"の場合は次行のインデントレベルをプラス
    var vMatchesStart_1 = vLineBody.match(/\{/g);
    if (vMatchesStart_1) {
        vIndentLv = vIndentLv + vMatchesStart_1.length;
    }
    
    // [A2ML以降] 末尾が"/begin "の場合は次行のインデントレベルをプラス
    var vMatchesStart_2 = vLineBody.match(/\/begin\s/g);
    if (vMatchesStart_2) {
        vIndentLv = vIndentLv + vMatchesStart_2.length;
        if(vLineBody.match(/\/begin\sA2ML/g)){
            vA2mlLineOn = true; // A2ML以外の行となったためfalse
        }
    }
        
    // [A2ML内] 末尾が"}"の場合は次行のインデントレベルをマイナス
    var vMatchesEnd_1 = vLineBody.match(/\}/g);
    if (vMatchesEnd_1) {
        vIndentLv = vIndentLv - vMatchesEnd_1.length;
        vIndentLv = vIndentLv + vIndentAdjustLv;
    }
    
    // [A2ML以降] 末尾が"/end "の場合は次行のインデントレベルをマイナス
    var vMatchesEnd_2 = vLineBody.match(/\/end\s/g);
    if (vMatchesEnd_2) {
        vIndentLv = vIndentLv - vMatchesEnd_2.length;
        vIndentLv = vIndentLv + vIndentAdjustLv;
        if(vLineBody.match(/\/end\sA2ML/g)){
            vA2mlLineOn = false; // A2ML以外の行となったためfalse
        }
    }

    // 整形済みの行をvFormatLines[]に格納
    vFormatLines[vFormatLines.length] = vLineBody + vLineComm;
}

//------------------------------------------------------------------------------
// 行末コメントの位置揃え
//------------------------------------------------------------------------------
if(vParam_CommentFitOn){
    var vCommentGroup = [];
    var vCommentGroupNum = 0;
    var vFindCommentPre = false;
    vA2mlLineOn = false; // A2ML行の場合はtrue, A2ML行以外の記載はfalse

    if(!vParam_CommentFit_EndSpaceOfBodyOn){ // 本文とコメント間のスペース調整をしない場合はスペースなし
        vParam_CommentFit_EndSpaceOfBodyStr = "";
    }
    
    // 行末コメント位置を揃えるグループを取得
    for (var i in vFormatLines) {
        var vLine = vFormatLines[i];

        // A2MLの確認
        if(vParam_IndentForA2mlOn == false){ // A2ML内ではインデントしない場合
            if(vLine.match(/^\s*\/end\s+A2ML/)){
                vA2mlLineOn = false;    
            }
            else if((vLine.match(/^\s*\/begin\s+A2ML/))){
                vA2mlLineOn = true;
            }
            else if(vA2mlLineOn){
                continue; // A2ML内であればインデントしない
            }
        }

        // コメントがある行かどうかをチェック
        var vFindComment = false;
        if (vLine.match(/\/[\/\*]/)) { 
            vFindComment = true; // 「//」「/*」の場合
        }
        
        if (vFindComment) {
            if (!vFindCommentPre) {
                vCommentGroupNum++;
            }
            var vLineNumAll = vCommentGroup[vCommentGroupNum] || []; // vCommentGroup[vCommentGroupNum]がNULLの場合、初期値として空の配列[]を代入
            vLineNumAll[vLineNumAll.length] = i;
            vCommentGroup[vCommentGroupNum] = vLineNumAll; // Groupとなる行番号が配列に格納される
        }
        vFindCommentPre = vFindComment;
    }
    
    // グループ毎に行末コメントを揃える
    for (var i in vCommentGroup) {
        var vLineNumAll = vCommentGroup[i];
        var vMaxLen = 0;

        // グループ内で最も右側にあるコメントの位置を判定
        for (var j in vLineNumAll) {
            var vLineNum = vLineNumAll[j];
            var vLine = vFormatLines[vLineNum];

            vIndexNum = f_CheckCommentIndex(vLine); //コメントの位置を確認
            if (vIndexNum > vMaxLen)  vMaxLen = vIndexNum;// 最大サイズの決定
        }
        
        // 最も右側にあるコメントに位置を合わせる
        var vBodyIsBlank = true; // 「//」「/*」行の本文が空行、もしくはスペースのみの場合、true
        for (var j in vLineNumAll) {
            var vLineNum = vLineNumAll[j];
            var vLine = vFormatLines[vLineNum];
            
            // 「//」「/*」を含む行の処理
            vIndexNum = f_CheckCommentIndex(vLine); //コメントの位置を確認
            vLineBody = vLine.slice(0, vIndexNum); // 本体
            vLineComm = vLine.slice(vIndexNum, vLine.length); // コメント

            // 本体とコメントの間のスペースを調整。
            if(vParam_CommentFit_EndSpaceOfBodyOn) {
                vLineBody = vLineBody.replace(/\s*$/, ""); // 末尾の余分な空白を削除
            }

            var vAddLen = vMaxLen - vLineBody.length;
            var vSpaces = "";
            
            // コメント位置合わせのためのスペース挿入
            for (var k = 0; k < vAddLen; k++) vSpaces = vSpaces + " ";
            
            if(!(vLineBody.match(/^\s*$/))){ //本文がスペースのみ、もしくは空だった場合
                vLineBody = vLineBody + vSpaces + vParam_CommentFit_EndSpaceOfBodyStr; 
                vBodyIsBlank = false;
            }
            else if(vBodyIsBlank == false){ // /*-*/内の2行目以降
                if(vLineComm.match(/^\/\*/)){ // 「/*の場合は字下げしない」
                    vLineBody = vLineBody + vSpaces + vParam_CommentFit_EndSpaceOfBodyStr; 
                }
                else{
                    vLineBody = vLineBody + vSpaces + "   " +vParam_CommentFit_EndSpaceOfBodyStr; 
                }
            }
            else{ // コメントより左に本文がない場合
                vLineBody = vLineBody + vSpaces; 
            }
            
            vLine = vLineBody + vLineComm;

            // /*-*/で囲まれたコメント行にマークしていた「//___<COMMENT_ON>___」を削除する
            vLine = vLine.replace(/\/\/___<COMMENT___MARK>___/, ""); 
            vFormatLines[vLineNum] = vLine;
        }
    }
} // if(vParam_CommentFitOn)

//------------------------------------------------------------------------------
// ファイルに反映
//------------------------------------------------------------------------------
var vTextAll = vFormatLines.join(vParam_Crlf) + vParam_Crlf;
SelectAll(0);
InsText(vTextAll);
//--- EXIT ---


//==============================================================================
//
//  関数
//
//==============================================================================
// コメント位置を取得
function f_CheckCommentIndex(vLine){
    var vCommSra = '//';
    var vCommAsta = '/*';
    var vIndexNum_pre3 = vLine.indexOf(vCommSra);
    var vIndexNum_pre4 = vLine.indexOf(vCommAsta);    
    if(vIndexNum_pre3 == -1)                 vIndexNum = vIndexNum_pre4;
    else if(vIndexNum_pre4 == -1)            vIndexNum = vIndexNum_pre3;
    else if(vIndexNum_pre3 < vIndexNum_pre4) vIndexNum = vIndexNum_pre3;
    else                                     vIndexNum = vIndexNum_pre4;
    return vIndexNum;
}
