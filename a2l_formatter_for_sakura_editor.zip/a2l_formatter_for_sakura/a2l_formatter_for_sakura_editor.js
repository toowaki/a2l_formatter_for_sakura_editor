//==================================================================================
//
// A2L formatter for Sakura editor (JScript版)
//
//==================================================================================
//------------------------------------------------------------------------------
// ユーザ設定
//------------------------------------------------------------------------------
// インデントに関する設定
var vParam_IndentStr = "\t";// インデント文字 (例：タブ1文字なら\t、スペース4文字なら"    ")

// コメントに関する設定
var vParam_CommentFitOn = true;                      // 文末のコメント位置揃え(true:ON, false:OFF)
var vParam_CommentFit_ChangeEndSpaceOfBody = true;   // 本体とコメントとの間のコメントを指定したスペースに変換(true:ON, false:OFF)
var vParam_CommentFit_EndSpaceOfBody = "    ";       // 本体とコメントとの間のコメントの間のスペース

var vParam_TitleCommentIndentZero = false; // false:行頭が/*から始まる行はインデント0にて処理、true:その他の行と同じインデント処理


//==============================================================================
//
//  MAIN
//
//==============================================================================
//------------------------------------------------------------------------------
//  初期化
//------------------------------------------------------------------------------
var vParam_Crlf = "\n";        // 改行文字
var vCntAll = GetLineCount(0); // 全体の行数
var vCntPos = -1;              // 継続行の開始位置
var vIndentLv = 0;             // インデントレベル
var vFormatLines = [];         // インデント調整後の内容が格納される配列
var vIsComment = false;        // コメント行の場合、true
var vLineBody = "";            // インデント調整用 処理部
var vLineComm = "";            // インデント調整用 コメント部

// デバッグ用
var shell = new ActiveXObject("WScript.Shell"); //「shell.Popup("Debug");」のように使用して変数を確認

//------------------------------------------------------------------------------
// インデント調整
//------------------------------------------------------------------------------
for (var i = 1; i <= vCntAll; i++) { //ファイルの1行目から最終行まで処理
    var vLineOrg = GetLineStr(i).replace(/\r\n/,"").replace(/\n/,""); //文末の改行削除
    vLineOrg = vLineOrg.replace(/\s+$/, "").replace(/^\s+/, ""); // 文頭と文末の空白を削除

    //------------------------------------------
    // 本体とコメントに分ける
    //------------------------------------------
    if(!vIsComment){ //コメント状態でない
        if (vLineOrg.match(/\/[\/\*]/)) { //コメント開始文字「//」,「/*」を含む場合
            //コメントの位置を確認
            vIndexNum = f_CheckCommentIndex(vLineOrg);// コメント位置を取得
            vLineBody = vLineOrg.slice(0, vIndexNum); // 本体
            vLineComm = vLineOrg.slice(vIndexNum, vLineOrg.length); // コメント

            //もしコメント状態かつ、行に*/を含んでいる場合はコメント状態解除
            if(vLineComm.match(/\*\//))      vIsComment = false;
            else if(vLineComm.match(/^\/\//)) vIsComment = false;
            else                              vIsComment = true;
        }
        else{
            vIsComment = false;
            vLineBody = vLineOrg;
            vLineComm = "";
        }
    }
    else{ //コメント状態。 一つ前の行で/*があることを想定。
        if (vLineOrg.match(/\*\//)) {// 「*/」を含む場合
            vIsComment = false;
            var vIndexNum = vLineOrg.indexOf('*/');// 「*/」の位置を取得
            vLineComm = vLineOrg.slice(0, vIndexNum+2); //コメント特殊文字2文字分加算してコメントと本体に分ける
            vLineBody = vLineOrg.slice(vIndexNum+2, vLineOrg.length);
        }
        else{
            vLineBody = "";
            vLineComm = vLineOrg;
        }
        
        // 「/*」のコメント中であることをマークする
        if(vParam_CommentFitOn) vLineBody = "//___<COMMENT___MARK>___" + vLineBody; 
    }

    // 本体とコメントの間のスペースを調整。「行末コメントの位置揃え」処理のため。
    if(vParam_CommentFitOn) {
        vLineBody = vLineBody.replace(/\s*$/, ""); // 末尾の余分な空白を削除
    }
    
    //------------------------------------------
    // インデントを揃える
    //------------------------------------------
    // 行頭が}、もしくは/endの時はインデントレベルをマイナス
    var vIndentAdjustLv = 0;
    if ((vLineBody.replace(/^\s+/,"").match(/^\}/)) ||
        (vLineBody.replace(/^\s+/,"").match(/^\/end\s/))){
        vIndentLv--;
        vIndentAdjustLv = 1;
    }

    // 行頭のインデントを揃える
    vLineBody = vLineBody.replace(/^(.*)$/, function(str, p1, p2){
        var vText = "";
        var vIndentOn = true;
        if(vParam_TitleCommentIndentZero == true){ // 行頭が/*で行についてのインデント処理
            if((vLineBody == "") && (vLineComm.match(/^\s*\/\*/))){// 行頭が/*から始まる行はインデント0にて処理
                vIndentOn = false;
            }
        }

        if(vIndentOn){
            for (var j = 0; j < vIndentLv; j++) {
                vText = vText + vParam_IndentStr;
            }
        }
        return vText + p1;
    });

    //------------------------------------------
    // 次行以降の処理に必要な情報の設定
    //------------------------------------------
    // [A2ML内] 末尾が"{"の場合は次行のインデントレベルをプラス
    var vMatchesStart_1 = vLineBody.match(/\{/g);
    if (vMatchesStart_1) {
        vIndentLv = vIndentLv + vMatchesStart_1.length;
    }
    
    // [A2ML以降] 末尾が"/begin "の場合は次行のインデントレベルをプラス
    var vMatchesStart_2 = vLineBody.match(/\/begin\s/g);
    if (vMatchesStart_2) {
        vIndentLv = vIndentLv + vMatchesStart_2.length;
    }
        
    // [A2ML内] 末尾が"}"の場合は次行のインデントレベルをマイナス
    var vMatchesEnd_1 = vLineBody.match(/\}/g);
    if (vMatchesEnd_1) {
        vIndentLv = vIndentLv - vMatchesEnd_1.length;
        vIndentLv = vIndentLv + vIndentAdjustLv;
    }
    
    // [A2ML以降] 末尾が"/end "の場合は次行のインデントレベルをマイナス
    var vMatchesEnd_2 = vLineBody.match(/\end\s/g);
    if (vMatchesEnd_2) {
        vIndentLv = vIndentLv - vMatchesEnd_2.length;
        vIndentLv = vIndentLv + vIndentAdjustLv;
    }

    // 整形済みの行をvFormatLines[]に格納
    vFormatLines[vFormatLines.length] = vLineBody + vLineComm;
}

//------------------------------------------------------------------------------
// 行末コメントの位置揃え
//------------------------------------------------------------------------------
if(vParam_CommentFitOn){
    var vCommentGroup = [];
    var vCommentGroupNum = 0;
    var vFindCommentPre = false;
    if(!vParam_CommentFit_ChangeEndSpaceOfBody){ //本文とコメント間のスペース調整をしない場合はスペースなし
        vParam_CommentFit_EndSpaceOfBody = "";
    }
    
    // 行末コメント位置を揃えるグループを取得
    for (var i in vFormatLines) {
        var vLine = vFormatLines[i];

        // 行末コメントがある行かどうかをチェック
        var vFindComment = false;
        if (vLine.match(/\/[\/\*]/)) { // '//' or '/*'の場合
            vFindComment = true;
        }
        
        if (vFindComment) {
            if (!vFindCommentPre) {
                vCommentGroupNum++;
            }
            var vLineNumAll = vCommentGroup[vCommentGroupNum] || []; //vCommentGroup[vCommentGroupNum]がNULLの場合、初期値として空の配列[]を代入
            vLineNumAll[vLineNumAll.length] = i;
            vCommentGroup[vCommentGroupNum] = vLineNumAll; //Groupとなる行番号が配列に格納される
        }
        vFindCommentPre = vFindComment;
    }
    
    // グループ毎に行末コメントを揃える
    for (var i in vCommentGroup) {
        var vLineNumAll = vCommentGroup[i];
        var vMaxLen = 0;

        // グループ内で最も右側にあるコメントの位置を判定
        for (var j in vLineNumAll) {
            var vLineNum = vLineNumAll[j];
            var vLine = vFormatLines[vLineNum];

            vIndexNum = f_CheckCommentIndex(vLine); //コメントの位置を確認
            if (vIndexNum > vMaxLen)  vMaxLen = vIndexNum;// 最大サイズの決定
        }
        
        // 最も右側にあるコメントに位置を合わせる
        var vBodyIsBlank = true; // 「//」「/*」行の本文が空行、もしくはスペースのみの場合、true
        for (var j in vLineNumAll) {
            var vLineNum = vLineNumAll[j];
            var vLine = vFormatLines[vLineNum];
            
            // 「//」「/*」を含む行の処理
            vIndexNum = f_CheckCommentIndex(vLine); //コメントの位置を確認
            vLineBody = vLine.slice(0, vIndexNum); // 本体
            vLineComm = vLine.slice(vIndexNum, vLine.length); // コメント
            
            var vAddLen = vMaxLen - vLineBody.length;
            var vSpaces = "";
            
            // コメント位置合わせのためのスペース挿入
            for (var k = 0; k < vAddLen; k++) vSpaces = vSpaces + " ";

            
            if(!(vLineBody.match(/^\s*$/))){//本文がスペースのみ、もしくは空だった場合
                vLineBody = vLineBody + vSpaces + vParam_CommentFit_EndSpaceOfBody; 
                vBodyIsBlank = false;
            }
            else if(vBodyIsBlank == false){// /*-*/内の2行目以降
                vLineBody = vLineBody + vSpaces + "   " +vParam_CommentFit_EndSpaceOfBody; 
            }
            else{ //コメントより左に本文がない場合
                vLineBody = vLineBody + vSpaces; 
            }
            
            vLine = vLineBody + vLineComm;

            // /*-*/で囲まれたコメント行にマークしていた「//___<COMMENT_ON>___」を削除する
            vLine = vLine.replace(/\/\/___<COMMENT___MARK>___/, ""); 
            vFormatLines[vLineNum] = vLine;
        }
    }
}//if(vParam_CommentFitOn)

//------------------------------------------------------------------------------
// ファイルに反映
//------------------------------------------------------------------------------
var vTextAll = vFormatLines.join(vParam_Crlf) + vParam_Crlf;
SelectAll(0);
InsText(vTextAll);
// <EXIT>


//==============================================================================
//
//  関数
//
//==============================================================================
// コメント位置を取得
function f_CheckCommentIndex(vLine){
    var vCommSra = '//';
    var vCommAsta = '/*';
    var vIndexNum_pre3 = vLine.indexOf(vCommSra);
    var vIndexNum_pre4 = vLine.indexOf(vCommAsta);    
    if(vIndexNum_pre3 == -1)                 vIndexNum = vIndexNum_pre4;
    else if(vIndexNum_pre4 == -1)            vIndexNum = vIndexNum_pre3;
    else if(vIndexNum_pre3 < vIndexNum_pre4) vIndexNum = vIndexNum_pre3;
    else                                     vIndexNum = vIndexNum_pre4;
    return vIndexNum;
}
